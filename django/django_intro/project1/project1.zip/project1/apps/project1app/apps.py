from django.apps import AppConfig


class Project1AppConfig(AppConfig):
    name = 'project1app'
