from django.shortcuts import render, redirect
from .models import Order, Product
from django.db.models import Avg, Count, Min, Sum

def index(request):
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)


def checkout1(request):
    theLastInstance = Order.objects.last()
    quantity_from_form = theLastInstance.quantity_ordered
    price_from_form = theLastInstance.total_price
    total_charge = quantity_from_form * price_from_form
    price = Order.objects.aggregate(Sum('total_price')).get("total_price__sum",0.0)
    context = {
            "total": total_charge,
            "Quantity": quantity_from_form,
            "Price":price_from_form,
            "totalQ": Order.objects.count(),
            "totalP": price,  
        }
    return  render(request,"store/checkout.html",context)

def checkout(request):
    if request.method == "POST":
        quantity_from_form = int(request.POST["quantity"])
        # price_from_form = float(request.POST["price"])
        priceHolder = request.POST["productid"]
        price2 = Order.objects.get(id = priceHolder)
        price_from_form = price2.total_price
        total_charge = quantity_from_form * price_from_form
        print("Charging credit card...")
        Order.objects.create(quantity_ordered=quantity_from_form, total_price=total_charge)
        price = Order.objects.aggregate(Sum('total_price')).get("total_price__sum",0.0)   
    return redirect("/checkout1")
