from django.apps import AppConfig


class RestfulshowsappConfig(AppConfig):
    name = 'restfulShowsApp'
