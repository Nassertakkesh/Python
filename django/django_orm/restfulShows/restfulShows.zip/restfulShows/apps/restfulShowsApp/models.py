from django.db import models


class Shows(models.Model):
    title = models.CharField(max_length=45)
    network = models.CharField(max_length=45)
    description = models.TextField()
    release_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # fields removed for brevity
    def __repr__(self):
        return f"<Shows object: {self.title} ({self.id})>"

    # Shows.objects.create(title ="Stranger Things", network = "Netflix", description = "a show about a girl with powers and the 1980's", release_date = "2017-06-01")