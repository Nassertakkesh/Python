from django.apps import AppConfig


class LoginregistrationappsConfig(AppConfig):
    name = 'LoginRegistrationApps'
