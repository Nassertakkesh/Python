from flask import Flask, render_template, request, redirect
app = Flask(__name__)  



@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    
    print(request.form)
    Strawberry = request.form['strawberry']
    Raspberry = request.form['raspberry']
    Apple = request.form['apple']
    sum = int(Apple) + int(Raspberry) + int(Strawberry)
    first_name= request.form['first_name'] 
    last_name = request.form['last_name']
    return render_template("checkout.html", Apple=Apple, Raspberry=Raspberry, Strawberry=Strawberry, sum = sum, first_name= first_name, last_name= last_name)

   

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    